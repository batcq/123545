//
//  Screen.swift
//  ChantalUITests
//
//  Created by Андрей Голубев on 06.08.2024.
//  Copyright © 2024 Monte Thakkar. All rights reserved.
//

import XCTest

protocol Screen {
    var app: XCUIApplication { get }
}
